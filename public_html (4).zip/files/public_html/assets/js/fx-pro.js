(function(){
  "use strict";
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  // --- Auto-aplicar .fx donde haga sentido si aún no existe ---
  function autoTag(){
    const heroLeft = document.querySelector('.hero .grid > div:first-child');
    const heroCard = document.querySelector('.hero-card');
    if(heroLeft && !heroLeft.classList.contains('fx')) heroLeft.classList.add('fx','fx-left');
    if(heroCard && !heroCard.classList.contains('fx')) { heroCard.classList.add('fx','fx-right'); heroCard.setAttribute('data-parallax','.25'); }

    document.querySelectorAll('#servicios .qv-card').forEach((c,i)=>{
      if(!c.classList.contains('fx')){
        c.classList.add('fx', i%2 ? 'fx-left':'fx-right');
      }
    });

    document.querySelectorAll('.qv-list').forEach(ul=>{
      ul.setAttribute('data-stagger','70');
      ul.querySelectorAll(':scope > li').forEach(li=>{
        if(!li.classList.contains('fx')) li.classList.add('fx','fx-up');
      });
    });

    document.querySelectorAll('.qv-stack > *').forEach((el,i)=>{
      if(!el.classList.contains('fx')) el.classList.add('fx', (i%3===0?'fx-zoom': i%3===1?'fx-left':'fx-right'));
    });

    document.querySelectorAll('section h2').forEach(h=>{
      if(!h.classList.contains('fx')) h.classList.add('fx','fx-up');
    });

    document.querySelectorAll('.qv-form').forEach(f=>{
      if(!f.classList.contains('fx')) f.classList.add('fx','fx-zoom');
    });
  }

  // --- IO + stagger ---
  function runObserver(){
    const nodes=[...document.querySelectorAll('.fx')];
    if(!nodes.length) return;

    if(typeof IntersectionObserver!=='function'){
      // Fallback: entrar todo
      nodes.forEach(n=>n.classList.add('is-in'));
      return;
    }

    const io=new IntersectionObserver((entries)=>{
      entries.forEach(entry=>{
        if(!entry.isIntersecting) return;
        const el=entry.target;
        // stagger por contenedor
        let delay=0;
        const p=el.parentElement;
        if(p && p.hasAttribute('data-stagger')){
          const step=Number(p.getAttribute('data-stagger'))||70;
          const sib=[...p.children].filter(n=>n.classList && n.classList.contains('fx'));
          const idx=sib.indexOf(el);
          delay = Math.max(0, idx*step);
        }
        el.style.transitionDelay = `${delay}ms`;
        el.classList.add('is-in');
        io.unobserve(el);
      });
    },{threshold:.15, rootMargin:'0px 0px -8%'});

    nodes.forEach(n=>io.observe(n));
  }

  // --- Parallax suave ---
  function parallax(){
    const ps=[...document.querySelectorAll('[data-parallax]')];
    if(!ps.length) return;
    let ticking=false;
    const coef = n => Math.min(.6, Math.max(-.6, Number(n)||.2));
    function step(){
      const mid = innerHeight*0.5;
      ps.forEach(el=>{
        const r=el.getBoundingClientRect();
        const c=coef(el.dataset.parallax);
        const off=(r.top-mid)*c*-0.06;
        el.style.transform = `translate3d(0,${off.toFixed(2)}px,0)`;
      });
      ticking=false;
    }
    addEventListener('scroll',()=>{ if(!ticking){ ticking=true; requestAnimationFrame(step); } }, {passive:true});
    step();
  }

  // --- Smooth anchors + autocierre del bottom-sheet (#qvToggle) ---
  function anchorsAndSheet(){
    const toggle=document.getElementById('qvToggle');
    document.addEventListener('click',(e)=>{
      const a=e.target.closest('a[href^="#"]'); if(!a) return;
      const id=a.getAttribute('href'); if(!id || id==='#' || id.length<2) return;
      const t=document.querySelector(id); if(!t) return;
      e.preventDefault();
      if(toggle) toggle.checked=false;
      t.scrollIntoView({behavior:'smooth',block:'start'});
    });
  }

  // --- Header oculto al bajar / visible al subir (sticky smart) ---
  function smartHeader(){
    const header=document.getElementById('qv-header');
    if(!header) return;
    let last=scrollY, hidden=false, H=header.offsetHeight||72;
    function tick(){
      const y=scrollY;
      const goingDown = y>last;
      const far = Math.abs(y-last)>6;
      if(far){
        if(goingDown && !hidden && y>H){ header.style.transform='translateY(-100%)'; hidden=true; }
        else if(!goingDown && hidden){ header.style.transform='translateY(0)'; hidden=false; }
        last=y;
      }
    }
    addEventListener('scroll', tick, {passive:true});
  }

  document.addEventListener('DOMContentLoaded', ()=>{
    autoTag();
    if(!reduce){ runObserver(); parallax(); }
    anchorsAndSheet();
    smartHeader();
  });
})();
