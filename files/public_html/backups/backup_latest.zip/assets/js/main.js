// ===== Scroll suave (anclas) =====
document.addEventListener('click', e=>{
  const a=e.target.closest('a[href^="#"]'); if(!a) return;
  const id=a.getAttribute('href'); if(id.length<2) return;
  e.preventDefault(); document.querySelector(id)?.scrollIntoView({behavior:'smooth',block:'start'});
});

// ===== Header: montar cuando el fetch termine =====
(function(){
  const mount = ()=>{
    const burger = document.querySelector('.qv-burger');
    const panel  = document.getElementById('qv-nav');
    if(!burger || !panel) return false;

    const setOpen = v=>{
      burger.setAttribute('aria-expanded', v);
      panel.hidden = !v;
      panel.setAttribute('aria-hidden', String(!v));
      panel.style.maxHeight = v ? (panel.scrollHeight+'px') : '0';
    };
    setOpen(false);

    burger.onclick = ()=> setOpen(burger.getAttribute('aria-expanded')!=='true');
    panel.addEventListener('click', e=>{
      if(e.target.closest('a[href^="#"]')) setOpen(false);
    });
    let last = window.scrollY;
    window.addEventListener('scroll', ()=>{
      if(Math.abs(window.scrollY-last)>30){ setOpen(false); last=window.scrollY; }
    });
    return true;
  };

  // 1) intenta montar ahora
  if(mount()) return;

  // 2) observa el placeholder del header hasta que aparezca
  const ph = document.getElementById('header-placeholder');
  if(ph){
    const mo = new MutationObserver(()=>{
      if(mount()){ mo.disconnect(); }
    });
    mo.observe(ph, {childList:true, subtree:true});
  }else{
    // 3) fallback por si cambia el HTML
    const it = setInterval(()=>{ if(mount()) clearInterval(it); }, 300);
    setTimeout(()=>clearInterval(it), 8000);
  }
})();
// === Menú NEO (sin hamburguesa) ===
(function(){
  const btn  = document.querySelector('.qv-menu-btn');
  const panel= document.getElementById('qv-menu-panel');
  if(!btn || !panel) return;

  const setOpen = (v)=>{
    btn.setAttribute('aria-expanded', v);
    panel.hidden = !v;
    panel.setAttribute('aria-hidden', String(!v));
    // max-height animado lo maneja CSS
  };
  setOpen(false);

  btn.addEventListener('click', ()=> setOpen(btn.getAttribute('aria-expanded')!=='true'));

  // Cerrar al hacer click en un enlace del panel
  panel.addEventListener('click', e=>{
    if(e.target.closest('a[href^="#"]')) setOpen(false);
  });

  // Cerrar con Esc o click fuera
  document.addEventListener('keydown', e=>{ if(e.key==='Escape') setOpen(false); });
  document.addEventListener('click', e=>{
    if(!panel.contains(e.target) && !btn.contains(e.target)) setOpen(false);
  });

  // Cerrar al scrollear (para que no tape nada)
  let last=window.scrollY;
  window.addEventListener('scroll', ()=>{
    if(Math.abs(window.scrollY-last)>30){ setOpen(false); last=window.scrollY; }
  });
})();
// ===== Command Palette (Ctrl/Cmd+K) =====
(function(){
  const overlay = document.getElementById('qv-cmd');
  const btn     = document.querySelector('.qv-cmd-btn');
  const input   = document.getElementById('qv-cmd-input');
  if(!overlay || !btn || !input) return;

  const items = Array.from(overlay.querySelectorAll('.qv-cmd-item'));
  const body  = document.body;

  function openCmd(){
    overlay.hidden = false; overlay.setAttribute('aria-hidden','false');
    btn.setAttribute('aria-expanded','true'); body.style.overflow='hidden';
    requestAnimationFrame(()=> input.focus());
  }
  function closeCmd(){
    overlay.hidden = true; overlay.setAttribute('aria-hidden','true');
    btn.setAttribute('aria-expanded','false'); body.style.overflow='';
    input.value=''; items.forEach(i=> i.style.display='flex');
  }
  btn.addEventListener('click', ()=> (overlay.hidden ? openCmd() : closeCmd()));

  // Keyboard: Ctrl/Cmd+K abre
  window.addEventListener('keydown', (e)=>{
    const k = e.key.toLowerCase();
    if((e.ctrlKey || e.metaKey) && k==='k'){ e.preventDefault(); openCmd(); }
    if(k==='escape'){ closeCmd(); }
  });

  // Cerrar por click fuera
  overlay.addEventListener('click', (e)=>{ if(e.target===overlay) closeCmd(); });

  // Filtrado en vivo
  input.addEventListener('input', ()=>{
    const q = input.value.trim().toLowerCase();
    items.forEach(el=>{
      const label = (el.dataset.label || el.textContent || '').toLowerCase();
      el.style.display = label.includes(q) ? 'flex' : 'none';
    });
  });

  // Navegar + cerrar
  overlay.addEventListener('click', (e)=>{
    const a = e.target.closest('a[href]');
    if(!a) return;
    if(a.getAttribute('href').startsWith('#')){
      e.preventDefault();
      document.querySelector(a.getAttribute('href'))?.scrollIntoView({behavior:'smooth',block:'start'});
    }
    closeCmd();
  });

  // Cerrar al scrollear
  let lastY = window.scrollY;
  window.addEventListener('scroll', ()=>{
    if(!overlay.hidden && Math.abs(window.scrollY - lastY) > 20) closeCmd();
    lastY = window.scrollY;
  });
})();
// ===== Header sheet (móvil) =====
(function(){
  const btn = document.querySelector('.hd__btn');
  const sheet = document.getElementById('hd-sheet');
  if(!btn || !sheet) return;

  const body = document.body;

  function openSheet(){
    sheet.hidden = false; sheet.setAttribute('aria-hidden','false');
    btn.setAttribute('aria-expanded','true'); body.style.overflow='hidden';
  }
  function closeSheet(){
    sheet.hidden = true; sheet.setAttribute('aria-hidden','true');
    btn.setAttribute('aria-expanded','false'); body.style.overflow='';
  }

  btn.addEventListener('click', ()=> sheet.hidden ? openSheet() : closeSheet());
  sheet.addEventListener('click', (e)=>{ if(e.target===sheet) closeSheet(); });
  window.addEventListener('keydown', (e)=>{ if(e.key==='Escape') closeSheet(); });

  // Navega y cierra
  sheet.addEventListener('click', (e)=>{
    const a = e.target.closest('a[href^="#"]');
    if(!a) return;
    e.preventDefault();
    document.querySelector(a.getAttribute('href'))?.scrollIntoView({behavior:'smooth',block:'start'});
    closeSheet();
  });
})();
// ===== Header v2 bootstrap (espera a que el fetch inserte el header) =====
(function initHeaderV2(){
  const root = document.getElementById('header-placeholder') || document.body;
  const boot = () => {
    const btn   = document.querySelector('.hd2__btn');
    const sheet = document.getElementById('hd2-sheet');
    if(!btn || !sheet) return false;

    const open  = () => {
      sheet.hidden = false;
      sheet.setAttribute('aria-hidden','false');
      btn.setAttribute('aria-expanded','true');
      document.body.style.overflow='hidden';
    };
    const close = () => {
      sheet.setAttribute('aria-hidden','true');
      btn.setAttribute('aria-expanded','false');
      document.body.style.overflow='';
      // ocultar tras animación
      setTimeout(()=>{ if(sheet.getAttribute('aria-hidden')==='true') sheet.hidden = true; }, 220);
    };

    btn.addEventListener('click', ()=> sheet.hidden ? open() : close());
    sheet.addEventListener('click', e => { if(e.target === sheet) close(); });
    window.addEventListener('keydown', e => { if(e.key==='Escape') close(); });
    // Cerrar al navegar
    sheet.querySelectorAll('a[href^="#"]').forEach(a=>{
      a.addEventListener('click', e=>{
        e.preventDefault();
        document.querySelector(a.getAttribute('href'))?.scrollIntoView({behavior:'smooth', block:'start'});
        close();
      });
    });
    // Auto-cerrar si pasa a desktop
    window.addEventListener('resize', ()=>{ if(window.innerWidth>980) close(); });

    return true;
  };

  if(!boot()){
    const mo = new MutationObserver(() => { if(boot()){ mo.disconnect(); } });
    mo.observe(root, {childList:true, subtree:true});
    // fallback por si el header ya estaba pero tarde
    setTimeout(()=>boot(), 400);
  }
})();
// ===== Header Luxury v3 bootstrap =====
(function bootHeaderLux(){
  const root = document.getElementById('header-placeholder') || document.body;

  const attach = () => {
    const sheet  = document.getElementById('hdLuxSheet');
    const btn    = document.querySelector('.hdLux__menuBtn');
    const ddBtn  = document.querySelector('.hdLux__link--dd');
    const ddPane = document.querySelector('.hdLux__panel');
    if(!sheet || !btn) return false;

    const openDrawer = () => {
      sheet.hidden = false;
      sheet.setAttribute('aria-hidden','false');
      btn.setAttribute('aria-expanded','true');
      document.body.style.overflow='hidden';
    };
    const closeDrawer = () => {
      sheet.setAttribute('aria-hidden','true');
      btn.setAttribute('aria-expanded','false');
      document.body.style.overflow='';
      setTimeout(()=>{ if(sheet.getAttribute('aria-hidden')==='true') sheet.hidden = true; }, 220);
    };

    btn.addEventListener('click', ()=> sheet.hidden ? openDrawer() : closeDrawer());
    sheet.addEventListener('click', e => { if(e.target === sheet) closeDrawer(); });
    window.addEventListener('keydown', e => { if(e.key==='Escape') closeDrawer(); });
    sheet.querySelectorAll('a[href^="#"]').forEach(a=>{
      a.addEventListener('click', e=>{
        e.preventDefault();
        document.querySelector(a.getAttribute('href'))?.scrollIntoView({behavior:'smooth', block:'start'});
        closeDrawer();
      });
    });

    // Dropdown (desktop)
    if(ddBtn && ddPane){
      const openDD  = () => { ddPane.hidden = false; ddBtn.setAttribute('aria-expanded','true'); };
      const closeDD = () => { ddPane.hidden = true;  ddBtn.setAttribute('aria-expanded','false'); };

      // Abrir por hover en desktop, por click en touch
      const isTouch = matchMedia('(pointer: coarse)').matches;
      if(isTouch){
        ddBtn.addEventListener('click', (e)=>{ e.stopPropagation(); ddPane.hidden ? openDD() : closeDD(); });
        document.addEventListener('click', (e)=>{ if(!ddPane.contains(e.target)) closeDD(); });
      }else{
        ddBtn.addEventListener('mouseenter', openDD);
        ddPane.addEventListener('mouseenter', openDD);
        ddBtn.addEventListener('mouseleave', ()=> setTimeout(()=>{ if(!ddPane.matches(':hover')) closeDD(); }, 60));
        ddPane.addEventListener('mouseleave', closeDD);
      }
      // Cerrar al cambiar a móvil
      window.addEventListener('resize', ()=>{ if(innerWidth<=980) closeDD(); });
    }

    // Autocerrar drawer al pasar a desktop
    window.addEventListener('resize', ()=>{ if(innerWidth>980) closeDrawer(); });

    return true;
  };

  if(!attach()){
    const mo = new MutationObserver(()=>{ if(attach()){ mo.disconnect(); } });
    mo.observe(root, {childList:true, subtree:true});
    setTimeout(()=>attach(), 400);
  }
})();
// ===== Header CONTRASTE v4 =====
(function initHdPro(){
  function attach(){
    const sheet  = document.getElementById('hdProSheet');
    const btn    = document.querySelector('.hdPro__menuBtn');
    const ddBtn  = document.querySelector('.hdPro__link--dd');
    const ddPane = document.querySelector('.hdPro__panel');
    if(!document.querySelector('.hdPro')) return false;

    // Drawer móvil
    const openDrawer = () => {
      sheet.hidden = false;
      sheet.setAttribute('aria-hidden','false');
      btn?.setAttribute('aria-expanded','true');
      document.body.style.overflow = 'hidden';
    };
    const closeDrawer = () => {
      sheet.setAttribute('aria-hidden','true');
      btn?.setAttribute('aria-expanded','false');
      document.body.style.overflow = '';
      setTimeout(()=>{ if(sheet.getAttribute('aria-hidden')==='true') sheet.hidden = true; }, 220);
    };
    btn?.addEventListener('click', ()=> sheet.hidden ? openDrawer() : closeDrawer());
    sheet?.addEventListener('click', e => { if(e.target === sheet) closeDrawer(); });
    window.addEventListener('keydown', e => { if(e.key==='Escape') closeDrawer(); });
    sheet?.querySelectorAll('a[href^="#"]').forEach(a=>{
      a.addEventListener('click', e=>{
        e.preventDefault();
        document.querySelector(a.getAttribute('href'))?.scrollIntoView({behavior:'smooth'});
        closeDrawer();
      });
    });

    // Dropdown escritorio
    if(ddBtn && ddPane){
      const openDD  = () => { ddPane.hidden = false; ddBtn.setAttribute('aria-expanded','true'); };
      const closeDD = () => { ddPane.hidden = true;  ddBtn.setAttribute('aria-expanded','false'); };

      const isTouch = matchMedia('(pointer: coarse)').matches;
      if(isTouch){
        ddBtn.addEventListener('click', (e)=>{ e.stopPropagation(); ddPane.hidden ? openDD() : closeDD(); });
        document.addEventListener('click', (e)=>{ if(!ddPane.contains(e.target) && e.target!==ddBtn) closeDD(); });
      }else{
        ddBtn.addEventListener('mouseenter', openDD);
        ddPane.addEventListener('mouseenter', openDD);
        ddBtn.addEventListener('mouseleave', ()=> setTimeout(()=>{ if(!ddPane.matches(':hover')) closeDD(); }, 60));
        ddPane.addEventListener('mouseleave', closeDD);
      }
      window.addEventListener('resize', ()=>{ if(innerWidth<=980) closeDD(); });
    }

    // Cerrar drawer si pasas a desktop
    window.addEventListener('resize', ()=>{ if(innerWidth>980) closeDrawer(); });

    return true;
  }

  if(!attach()){
    const mo = new MutationObserver(()=>{ if(attach()) mo.disconnect(); });
    mo.observe(document.documentElement, {childList:true, subtree:true});
    setTimeout(()=>attach(), 400);
  }
})();
// ===== QivoDigital · Header/Menu logic =====
(function(){
  const menuBtn   = document.querySelector('.qv-menu-btn');
  const panel     = document.getElementById('qv-menu');
  const overlay   = document.getElementById('qv-overlay');
  const closeBtn  = document.querySelector('.qv-menu__close');
  const links     = panel ? panel.querySelectorAll('a.qv-link[href^="#"]') : [];

  if(!menuBtn || !panel || !overlay){ return; }

  const open = () => {
    panel.classList.add('is-open');
    overlay.classList.add('is-on'); overlay.hidden = false;
    menuBtn.setAttribute('aria-expanded','true');
    document.body.classList.add('qv-no-scroll');
  };

  const close = () => {
    panel.classList.remove('is-open');
    overlay.classList.remove('is-on');
    menuBtn.setAttribute('aria-expanded','false');
    document.body.classList.remove('qv-no-scroll');
    // overlay se oculta al terminar la animación
    setTimeout(()=>{ overlay.hidden = true; }, 220);
  };

  menuBtn.addEventListener('click', (e)=>{ e.preventDefault(); open(); });
  closeBtn?.addEventListener('click', close);
  overlay.addEventListener('click', close);
  window.addEventListener('keydown', (e)=>{ if(e.key==='Escape') close(); });

  // Al hacer clic en un enlace: cerrar y navegar suave
  links.forEach(a=>{
    a.addEventListener('click', (e)=>{
      const id = a.getAttribute('href');
      if(id && id.startsWith('#')){
        e.preventDefault();
        close();
        const el = document.querySelector(id);
        if(el){ el.scrollIntoView({behavior:'smooth', block:'start'}); }
      }
    });
  });
})();
